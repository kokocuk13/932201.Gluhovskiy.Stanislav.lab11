﻿namespace lab11.ViewModels
{
    public class CalcViewModel
    {
        public int firstValue;
        public int secondValue;
        public int additionResult;
        public int subtractionResult;
        public int multiplicationResult;
        public int divisionResult;
    }
}
