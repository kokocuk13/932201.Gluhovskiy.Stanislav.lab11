﻿using lab11.ViewModels;

namespace lab11.Interfaces
{
    public interface ICalcService
    {
        CalcViewModel createCalcViewModel();
    }
}
